﻿using CapitalClash.Application.Commands;
using CapitalClash.Models;
using CapitalClash.Services;
using MediatR;

namespace CapitalClash.Application.Handlers
{
    public class RollDiceHandler : IRequestHandler<RollDiceCommand>
    {
        private readonly GameService _gameService;

        public RollDiceHandler(GameService gameService)
        {
            _gameService = gameService;
        }

        public async Task<Unit> Handle(RollDiceCommand request, CancellationToken cancellationToken)
        {
            if (!GameStore.Rooms.TryGetValue(request.RoomCode, out var room)) return Unit.Value;

            var player = room.Players.FirstOrDefault(p => p.ConnectionId == request.ConnectionId);
            if (player == null || room.CurrentTurnPlayerId != player.Id) return Unit.Value;

            await _gameService.ExecuteTurn(room, player, request.Clients, request.RoomCode);

            return Unit.Value;
        }
    }
}
