﻿using System.Collections.Concurrent;

namespace CapitalClash.Models
{

    public static class GameStore
    {
        public static ConcurrentDictionary<string, GameRoom> Rooms { get; } = new();
    }

}
