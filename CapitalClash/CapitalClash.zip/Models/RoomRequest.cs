﻿namespace CapitalClash.Models
{
    public class RoomRequest
    {
        public bool IsPrivate { get; set; }
        public string? Password { get; set; }
    }
}
