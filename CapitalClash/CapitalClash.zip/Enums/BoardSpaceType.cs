﻿namespace CapitalClash.Enums
{
    public enum BoardSpaceType
    {

        Start,
        Property,
        Chance,
        Tax,
        Jail,
        FreeParking,
        GoToJail

    }
}
