﻿using CapitalClash.Application.Commands;
using CapitalClash.Enums;
using CapitalClash.Models;
using CapitalClash.Services;
using CapitalClash.Services.Actions;
using MediatR;
using Microsoft.AspNetCore.SignalR;

namespace CapitalClash.Hubs
{
    public class GameHub : Hub
    {
        private readonly IMediator _mediator;

        public GameHub(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task JoinRoom(string roomCode, string nickname, string? password = null)
        {
            if (!GameStore.Rooms.TryGetValue(roomCode, out var room)) return;

            if (room.IsPrivate && room.Password != password)
            {
                await Clients.Caller.SendAsync("JoinFailed", "Senha incorreta.");
                return;
            }

            var player = new Player
            {
                Nickname = nickname,
                ConnectionId = Context.ConnectionId,
                Balance = GameConfig.InitialBalance
            };

            room.Players.Add(player);
            room.State.PlayerPositions[player.Id] = 0;

            if (room.CurrentTurnPlayerId == null)
            {
                room.CurrentTurnPlayerId = player.Id;
                room.LastTurnTime = DateTime.UtcNow;
            }

            await Groups.AddToGroupAsync(Context.ConnectionId, roomCode);
            await Clients.Group(roomCode).SendAsync("PlayerJoined", nickname);
        }

        public async Task RollDice(string roomCode)
        {
            var command = new RollDiceCommand
            {
                RoomCode = roomCode,
                ConnectionId = Context.ConnectionId,
                Clients = Clients
            };

            await _mediator.Send(command);
        }

        public async Task BuyProperty(string roomCode)
        {
            await _mediator.Send(new BuyPropertyCommand
            {
                RoomCode = roomCode,
                ConnectionId = Context.ConnectionId,
                Clients = Clients
            });
        }

        public async Task UpgradeProperty(string roomCode)
        {
            await _mediator.Send(new UpgradePropertyCommand
            {
                RoomCode = roomCode,
                ConnectionId = Context.ConnectionId,
                Clients = Clients
            });
        }

        public async Task PayJailFine(string roomCode)
        {
            await _mediator.Send(new PayJailFineCommand
            {
                RoomCode = roomCode,
                ConnectionId = Context.ConnectionId,
                Clients = Clients
            });
        }

        public override async Task OnDisconnectedAsync(Exception? exception)
        {
            foreach (var room in GameStore.Rooms.Values)
            {
                var player = room.Players.FirstOrDefault(p => p.ConnectionId == Context.ConnectionId);
                if (player != null)
                {
                    room.Players.Remove(player);
                    room.State.PlayerPositions.Remove(player.Id);

                    if (room.CurrentTurnPlayerId == player.Id && room.Players.Any())
                    {
                        var next = room.Players.First();
                        room.CurrentTurnPlayerId = next.Id;
                        await Clients.Group(room.RoomCode).SendAsync("NextTurn", next.Nickname);
                    }

                    await Clients.Group(room.RoomCode).SendAsync("PlayerLeft", player.Nickname);
                    break;
                }
            }

            await base.OnDisconnectedAsync(exception);
        }
    }
}
